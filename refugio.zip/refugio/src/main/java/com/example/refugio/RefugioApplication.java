package com.example.refugio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefugioApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefugioApplication.class, args);
	}

}
